import React, { useEffect, useState } from 'react'
import './Dashboard.css'

const LOCAL_STORAGE_KEY = 'comments_dashboard_state'

function Dashboard() {
  const [comments, setComments] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [searchText, setSearchText] = useState('')
  const [sortConfig, setSortConfig] = useState({ key: null, direction: null })
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)

  // Load localStorage (on first mount)
  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY))
    if (saved) {
      setSearchText(saved.searchText || '')
      setSortConfig(saved.sortConfig || { key: null, direction: null })
      setCurrentPage(saved.currentPage || 1)
      setPageSize(saved.pageSize || 10)
    }
  }, [])

  // Fetch data (only once)
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/comments')
      .then(res => res.json())
      .then(data => setComments(data))
      .catch(err => console.error('Failed to fetch comments:', err))
  }, [])

  // Save to localStorage (whenever state changes)
  useEffect(() => {
    localStorage.setItem(
      LOCAL_STORAGE_KEY,
      JSON.stringify({ searchText, sortConfig, currentPage, pageSize })
    )
  }, [searchText, sortConfig, currentPage, pageSize])

  // Filter + Sort
  useEffect(() => {
    let result = comments.filter(comment =>
      comment.name.toLowerCase().includes(searchText.toLowerCase()) ||
      comment.email.toLowerCase().includes(searchText.toLowerCase()) ||
      comment.body.toLowerCase().includes(searchText.toLowerCase())
    )

    if (sortConfig.key) {
      result.sort((a, b) => {
        let valA = a[sortConfig.key]
        let valB = b[sortConfig.key]

        const isString = ['name', 'email', 'body'].includes(sortConfig.key)
        if (!isString) {
          valA = Number(valA)
          valB = Number(valB)
        } else {
          valA = valA.toLowerCase()
          valB = valB.toLowerCase()
        }

        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1
        return 0
      })
    }

    setFilteredData(result)
  }, [comments, searchText, sortConfig])

  const startIndex = (currentPage - 1) * pageSize
  const paginatedData = filteredData.slice(startIndex, startIndex + pageSize)
  const totalPages = Math.ceil(filteredData.length / pageSize)

  const handleSort = key => {
    if (sortConfig.key !== key) {
      setSortConfig({ key, direction: 'asc' })
    } else if (sortConfig.direction === 'asc') {
      setSortConfig({ key, direction: 'desc' })
    } else if (sortConfig.direction === 'desc') {
      setSortConfig({ key: null, direction: null })
    } else {
      setSortConfig({ key, direction: 'asc' })
    }
  }

  return (
    <div className="dashboard-container">
      <h1>Dashboard</h1>

      <div className="dashboard-header">
        <div className="sort-buttons">
          <button onClick={() => handleSort('id')}>
            Sort ID {sortConfig.key === 'id' ? `(${sortConfig.direction})` : ''}
          </button>
          <button onClick={() => handleSort('postId')}>
            Sort Post ID {sortConfig.key === 'postId' ? `(${sortConfig.direction})` : ''}
          </button>
          <button onClick={() => handleSort('name')}>
            Sort Name {sortConfig.key === 'name' ? `(${sortConfig.direction})` : ''}
          </button>
          <button onClick={() => handleSort('email')}>
            Sort Email {sortConfig.key === 'email' ? `(${sortConfig.direction})` : ''}
          </button>
        </div>

        <input
          type="text"
          className="search-input"
          placeholder="Search name, email, comment"
          value={searchText}
          onChange={e => {
            setSearchText(e.target.value)
            setCurrentPage(1)
          }}
        />
      </div>

      <div className="table-wrapper">
        <table className="comments-table">
          <thead>
            <tr>
              <th className='id'>ID</th>
              <th className='id'>Post ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Comment</th>
            </tr>
          </thead>
          <tbody>
            {paginatedData.length === 0 ? (
              <tr>
                <td colSpan="5" style={{ textAlign: 'center', padding: '20px', color: '#888' }}>
                  No results found.
                </td>
              </tr>
            ) : (
              paginatedData.map(comment => (
                <tr key={comment.id}>
                  <td>{comment.id}</td>
                  <td>{comment.postId}</td>
                  <td title={comment.name}>{comment.name}</td>
                  <td title={comment.email}>{comment.email}</td>
                  <td title={comment.body}>{comment.body}</td>
                </tr>
              ))
            )}
          </tbody>

        </table>
      </div>

      <div className="pagination-footer">
        <span>
          {startIndex + 1}-{Math.min(startIndex + pageSize, filteredData.length)} of {filteredData.length} items
        </span>

        <div className="pagination-controls">
          <button
            onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
            disabled={currentPage === 1}
          >
            &laquo;
          </button>

          {currentPage > 2 && (
            <>
              <button onClick={() => setCurrentPage(1)}>1</button>
              {currentPage > 3 && <span className="dots">...</span>}
            </>
          )}

          {currentPage > 1 && (
            <button onClick={() => setCurrentPage(currentPage - 1)}>
              {currentPage - 1}
            </button>
          )}

          <button className="active">{currentPage}</button>

          {currentPage < totalPages && (
            <button onClick={() => setCurrentPage(currentPage + 1)}>
              {currentPage + 1}
            </button>
          )}

          {currentPage < totalPages - 1 && (
            <>
              {currentPage < totalPages - 2 && <span className="dots">...</span>}
              <button onClick={() => setCurrentPage(totalPages)}>{totalPages}</button>
            </>
          )}

          <button
            onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            &raquo;
          </button>

          <select
            value={pageSize}
            onChange={e => {
              setPageSize(Number(e.target.value))
              setCurrentPage(1)
            }}
          >
            <option value={10}>10 / Page</option>
            <option value={50}>50 / Page</option>
            <option value={100}>100 / Page</option>
          </select>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
