import React, { useContext } from 'react'
import { useNavigate } from 'react-router-dom'
import './Profile.css'
import UserContext from '../../contexts/UserContext'

function Profile() {
  const user = useContext(UserContext)
  const navigate = useNavigate()

  if (!user) return <p>Loading profile...</p>

  return (
    <div className="profile-container">
      <div className='name-close-container'>
        <h1>Welcome, {user.name}</h1>
        <button onClick={() => user && navigate('/')} className='close-button'>X</button>
      </div>
      {/* <button onClick={() => navigate('/')}>← Back to Dashboard</button> */}
      <div
                onClick={() => user && navigate('/profile')}
                className="avatar"
                title={user?.name || 'Loading...'}
            >
                <h3>{user ? user.name[0] : '...'}</h3>
        </div>

      <div className="profile-info">
        <p><strong className='pro-details'>User ID:</strong> {user.id}</p>
        <p><strong className='pro-details'>Name:</strong> {user.name}</p>
        <p><strong>Username:</strong> {user.username}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Phone:</strong> {user.phone}</p>
        <p><strong>Website:</strong> {user.website}</p>
        <p><strong>Company:</strong> {user.company?.name}</p>
        <p><strong>Address:</strong> {user.address?.suite}, {user.address?.street}, {user.address?.city}, {user.address?.zipcode}</p>
      </div>
    </div>
  )
}

export default Profile
