import React, { useEffect, useState } from 'react'
import { Outlet, useNavigate } from 'react-router-dom'
import UserContext from '../../contexts/UserContext'
import './Layout.css'

function Layout() {
  const navigate = useNavigate()
  const [user, setUser] = useState(null)

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => res.json())
      .then(data => setUser(data[0]))
      .catch(err => console.error('User fetch error', err))
  }, [])

  return (
    <UserContext.Provider value={user}>
      <div className="layout-container">
        <header className="layout-header">
            <div>
                <h2 className="logo" onClick={() => navigate('/')}>Swift</h2>
            </div>

            <div
                onClick={() => user && navigate('/profile')}
                className="avatar"
                title={user?.name || 'Loading...'}
            >
                <h3>{user ? user.name[0] : '...'}</h3>
            </div>
        </header>

        <main className="layout-content">
          <Outlet />
        </main>
      </div>
    </UserContext.Provider>
  )
}

export default Layout
