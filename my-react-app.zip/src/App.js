import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Profile from './components/Profile/Profile'
import Dashboard from './components/Dashboard/Dashboard'
import Layout from './components/Layout/Layout'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="profile" element={<Profile />} />
        </Route>
      </Routes>
    </Router>
  )
}

export default App
